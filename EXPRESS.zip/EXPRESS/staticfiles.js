var express=require("express");
var app=express();

var port=process.env.PORT || 4000;

app.use('/assets',express.static(__dirname+'/public'));
//respond to http request
app.get('/',function(req,res) {
   res.send('<html><head></head><body><h1><link href=assets/style.css rel=stylesheet>how is angular</h1></body></html>')
});

app.get('/person/:id',function(req,res) {
    res.send('<html><head></head><body><h1>Person : '+req.params.id+'</h1></body></html>')
 });

app.get('/api',function(req,res) {
     res.json({fname:'mahadev',lname:'jawarge'});
});

app.listen(port);